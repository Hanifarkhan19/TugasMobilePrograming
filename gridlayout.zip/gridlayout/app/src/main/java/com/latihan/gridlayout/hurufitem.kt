package com.latihan.gridlayout

class hurufitem {
    var icons:Int ? = 0
    var alpha:String ? = null

    constructor(icons: Int?, alpha: String?) {
        this.icons = icons
        this.alpha = alpha
    }
}